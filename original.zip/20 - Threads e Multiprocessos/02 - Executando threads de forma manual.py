import time
import threading

inicio = time.perf_counter()

def dormir():
    print('Indo dormir por 1 segundo...')
    time.sleep(1)
    print('Terminei de dormir...')

t1 = threading.Thread(target=dormir)
t2 = threading.Thread(target=dormir)

t1.start()
t2.start()

# complete here before moving on
t1.join()
t2.join()

final = time.perf_counter()

print(f'Rodou em {round(final-inicio,3)} segundo(s)')

# func() <<<<< 1 second >>>>> func() <<<<<< 1 second >>>>>> Done
#--------------------------- time ------------------------------

# func() <<<<< 1 second >>>>>
#        func() <<<<<< 1 second >>>>>> Done
# ---------------- time -------------------


# I/O boud tasks - waiting - reading/writing files,file operations,
# network operations, download stuff online,

# CPU boud tasks - using the cpu
# not threading / sometimes is slow
# much likely to use multiprocessing
