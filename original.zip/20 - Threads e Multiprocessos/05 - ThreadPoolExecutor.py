import time
import concurrent.futures

inicio = time.perf_counter()

def dormir(segundos):
    print(f'Indo dormir por {segundos} segundo(s)...')
    time.sleep(segundos)
    return 'Terminei de dormir...'

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor() as executor:
        f1 = executor.submit(dormir, 1)
        f2 = executor.submit(dormir, 1)

        print(f1.result())
        print(f2.result())
    final = time.perf_counter()

    print(f'Rodou em {round(final-inicio,3)} segundo(s)')
