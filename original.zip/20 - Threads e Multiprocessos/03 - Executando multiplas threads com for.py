import time
import threading

inicio = time.perf_counter()

def dormir():
    print('Indo dormir por 1 segundo...')
    time.sleep(1)
    print('Terminei de dormir...')

threads = []
for _ in range(10):
    t = threading.Thread(target=dormir)
    t.start()
    threads.append(t)

for thread in threads:
    thread.join()

final = time.perf_counter()

print(f'Rodou em {round(final-inicio,3)} segundo(s)')

# func() <<<<< 1 second >>>>> func() <<<<<< 1 second >>>>>> Done
#--------------------------- time ------------------------------

# func() <<<<< 1 second >>>>>
#        func() <<<<<< 1 second >>>>>> Done
# ---------------- time -------------------


# I/O boud tasks - waiting - reading/writing files,file operations,
# network operations, download stuff online,

# CPU boud tasks - using the cpu
# not threading / sometimes is slow
# much likely to use multiprocessing
