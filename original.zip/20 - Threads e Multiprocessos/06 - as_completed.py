import time
import concurrent.futures

inicio = time.perf_counter()

def dormir(segundos):
    print(f'Indo dormir por {segundos} segundo(s)...')
    time.sleep(segundos)
    return 'Terminei de dormir...'

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor() as executor:
        results = [executor.submit(dormir, 1) for _ in range(10)]
        # as completed, yield results
        for f in concurrent.futures.as_completed(results):
            print(f.result())

    final = time.perf_counter()

    print(f'Rodou em {round(final-inicio,3)} segundo(s)')
