import time
import concurrent.futures

inicio = time.perf_counter()

def dormir(segundos):
    print(f'Indo dormir por {segundos} segundo(s)...')
    time.sleep(segundos)
    return f'Terminei de dormir {segundos} segundo(s)...'

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor() as executor:
        segundos = [5,4,3,2,1]
        results = [executor.submit(dormir, segundo) for segundo in segundos]
        # as completed, yield results
        for f in concurrent.futures.as_completed(results):
            print(f.result())

    final = time.perf_counter()

    print(f'Rodou em {round(final-inicio,3)} segundo(s)')
