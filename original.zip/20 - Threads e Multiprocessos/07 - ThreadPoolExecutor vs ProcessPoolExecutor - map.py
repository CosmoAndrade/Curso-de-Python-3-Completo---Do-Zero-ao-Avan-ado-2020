import time
import concurrent.futures

inicio = time.perf_counter()

def dormir(segundos):
    print(f'Indo dormir por {segundos} segundo(s)...')
    time.sleep(segundos)
    return f'Terminei de dormir {segundos} segundo(s)...'

if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor() as executor:
        segundos = [5,4,3,2,1]
        # return the results in the order they started
        results = executor.map(dormir, segundos)
        for result in results:
            print(result)

    final = time.perf_counter()

    print(f'Rodou em {round(final-inicio,3)} segundo(s)')
