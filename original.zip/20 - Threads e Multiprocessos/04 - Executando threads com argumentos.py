import time
import threading

inicio = time.perf_counter()

def dormir(segundos):
    print(f'Indo dormir por {segundos} segundo(s)...')
    time.sleep(segundos)
    print('Terminei de dormir...')

threads = []
for _ in range(10):
    t = threading.Thread(target=dormir, args=[1.5])
    t.start()
    threads.append(t)

for thread in threads:
    thread.join()

final = time.perf_counter()

print(f'Rodou em {round(final-inicio,3)} segundo(s)')
