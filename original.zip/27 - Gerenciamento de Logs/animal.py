from app import log_manager

logger = log_manager(name='animal', filename='animal.log',log_level='INFO',handler_level='INFO')

class Animal:
    def __init__(self, nome, tipo):
        self.nome = nome
        self.tipo = tipo
        logger.info(f'Animal de nome "{self.nome}" e tipo "{self.tipo}" criado!')

cao = Animal('Rufus', 'canino')
gato = Animal('Mia', 'felino')
