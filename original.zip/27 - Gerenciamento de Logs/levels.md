# Levels de Logs

* **DEBUG**: Informação detalhada, tipicamente de interesse quando diagnosticando problemas.
<br><br>
* **INFO**: Confirmação que as coisas estão funcionando conforme o esperado.
<br><br>
* **WARNING**: Uma indicação que uma coisa inesperada aconteceu, ou indicativo de um problema num futuro próximo (ex: disco rígido com pouco espaço).
<br><br>
* **ERROR**: Devido a problemas mais sérios, o software não foi capaz de performar alguma tarefa.
<br><br>
* **CRITICAL**: Um problema sério, indicando que o próprio programa esteja incapaz de continuar rodando.

Referência
* https://docs.python.org/3/library/logging.html#logrecord-attributes
